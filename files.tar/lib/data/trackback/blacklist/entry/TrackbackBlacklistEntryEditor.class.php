<?php
namespace wcf\data\trackback\blacklist\entry;
use wcf\data\DatabaseObjectEditor;

/**
 * 
 * 
 * @author		Joshua Rüsweg
 * @copyright   
 * @license     
 * @package		com.hg-202.trackback
 * @subpackage  
 * @category    
 */
class TrackbackBlacklistEntryEditor extends DatabaseObjectEditor {
	/**
	 * @see	\wcf\data\DatabaseObjectDecorator::$baseClass
	 */
	protected static $baseClass = 'wcf\data\trackback\blacklist\entry\TrackbackBlacklistEntry';
}
